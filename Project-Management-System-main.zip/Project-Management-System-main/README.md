﻿# Project Management System

A comprehensive ASP.NET Core MVC application for managing enterprise projects, teams, employees, tasks, and financial operations with a robust database-driven architecture.

[![.NET](https://img.shields.io/badge/.NET-10.0-512BD4?style=flat&logo=dotnet)](https://dotnet.microsoft.com/)
[![MSSQL Server](https://img.shields.io/badge/SQL%20Server-Database-CC2927?style=flat&logo=microsoft-sql-server)](https://www.microsoft.com/sql-server)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Database Setup](#database-setup)
- [Configuration](#configuration)
- [Project Structure](#project-structure)
- [Usage](#usage)
- [Screenshots](#screenshots)
- [License](#license)
- [Author](#author)
- [Support](#support)

## ✨ Features

### Core Modules

- **📊 Dashboard**: Real-time overview of projects, employees, teams, tasks, and financial metrics
- **👥 Employee Management**: Complete CRUD operations for employee records with role assignments
- **📁 Project Management**: Track projects with budgets, deadlines, status, and descriptions
- **👨‍👩‍👧‍👦 Team Management**: Create and manage teams with member assignments
- **✅ Task Assignment**: Assign tasks to teams and track completion status
- **💬 Comments**: Add comments and notes to projects for collaboration
- **🏖️ Leave Management**: Employee leave request tracking and approval system
- **💰 Invoice Management**: Create and track project invoices with automatic calculations
- **📈 Profit Tracking**: Monitor project profitability and financial performance

### Technical Features

- **Repository Pattern**: Clean architecture with separation of concerns
- **Dependency Injection**: Scoped services for repositories
- **ADO.NET**: Direct database access using Microsoft.Data.SqlClient
- **Turkish Localization**: Currency formatting in Turkish Lira (₺)
- **Responsive Design**: Bootstrap 5 with modern UI components
- **Data Validation**: Model validation with DataAnnotations
- **Error Handling**: Comprehensive error management and logging

## 🛠️ Tech Stack

### Backend
- **.NET 10** - Latest .NET framework
- **ASP.NET Core MVC** - Web framework
- **ADO.NET** - Data access with Microsoft.Data.SqlClient 5.2.2
- **C# 13** - Programming language

### Frontend
- **Bootstrap 5** - UI framework
- **Bootstrap Icons** - Icon library
- **Razor Views** - Server-side rendering
- **HTML5/CSS3** - Markup and styling

### Database
- **Microsoft SQL Server** - Primary database
- **Integrated Security** - Windows Authentication

## 📦 Prerequisites

Before running this project, ensure you have the following installed:

- [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0) or later
- [Microsoft SQL Server](https://www.microsoft.com/sql-server/sql-server-downloads) (2019 or later recommended)
- [Visual Studio 2026](https://visualstudio.microsoft.com/) or [Visual Studio Code](https://code.visualstudio.com/)
- [Git](https://git-scm.com/) (for cloning the repository)

## 🚀 Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/Nuraddin0/Project-Management-System.git
   cd Project-Management-System
   ```

2. **Restore NuGet packages**
   ```bash
   cd DatabaseProject
   dotnet restore
   ```

3. **Build the project**
   ```bash
   dotnet build
   ```

## 🗄️ Database Setup

The project includes comprehensive SQL scripts located in the [`Database`](Database) folder to set up the complete database schema.

### Quick Setup

1. **Create the database**
   - Open SQL Server Management Studio (SSMS)
   - Connect to your SQL Server instance
   - Create a new database named `ProjectDB`
   ```sql
   CREATE DATABASE ProjectDB;
   GO
   USE ProjectDB;
   GO
   ```

2. **Execute the SQL scripts in order**
   
   Navigate to the `Database` folder and execute the following scripts:

   **a) [Tables.sql](Database/Tables.sql)** - Creates all database tables
   - `Employee` - Employee master table with unique username and email
   - `FullTimeEmployee` - Full-time employees with monthly salary
   - `HourlyEmployee` - Hourly employees with hourly rate
   - `Project` - Project information with budget and deadlines
   - `Team` - Team structure and details
   - `TeamMember` - Team member assignments
   - `TaskAssignment` - Task assignments to teams and projects
   - `Comment` - Comments on tasks/projects
   - `Leave` - Employee leave requests
   - `Invoice` - Project invoices and billing
   - `Profit` - Project profitability tracking
   - `DailyPerformance` - Employee daily work hours tracking

   **b) [StoredProcedures.sql](Database/StoredProcedures.sql)** - Creates stored procedures for business logic
   - `sp_Hiring_AddFullTime` - Add full-time employee with transaction safety
   - `sp_Hiring_AddHourly` - Add hourly employee with transaction safety
   - `sp_Accounting_GenerateInvoice` - Generate invoice for hourly employees
   - And more...

   **c) [Triggers.sql](Database/Triggers.sql)** - Creates database triggers for automation
   - `trg_Employee_AutoUpdateDate` - Auto-update employee modification timestamp
   - `trg_Comment_AutoUpdateDate` - Auto-update comment modification timestamp  
   - `trg_CheckBudgetOverflow` - Prevent project expenses from exceeding budget
   - `trg_AssignmentID_Constraint` - Validate assignment constraints

### Database Features

- **Employee Hierarchy**: Supports both full-time and hourly employees with specialized tables
- **Transaction Safety**: All insert/update operations wrapped in transactions
- **Data Integrity**: Foreign key constraints and unique constraints on critical fields
- **Automatic Timestamps**: Triggers automatically update modification dates
- **Budget Control**: Triggers prevent cost overruns on projects
- **Business Logic**: Stored procedures encapsulate complex operations

## ⚙️ Configuration

1. **Update the connection string**
   
   Open `appsettings.json` and update the connection string to match your SQL Server instance:

   ```json
   {
     "ConnectionStrings": {
       "DefaultConnection": "Data Source=YOUR_SERVER_NAME;Initial Catalog=ProjectDB;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False;Command Timeout=30"
     }
   }
   ```

   Replace `YOUR_SERVER_NAME` with your SQL Server instance name (e.g., `localhost`, `(localdb)\\MSSQLLocalDB`, or your server name).

2. **Run the application**
   ```bash
   dotnet run
   ```

3. **Access the application**
   
   Open your browser and navigate to:
   - `https://localhost:5001` (HTTPS)
   - `http://localhost:5000` (HTTP)

## 📂 Project Structure

```
DatabaseProject/
├── Controllers/           # MVC Controllers
│   ├── HomeController.cs
│   ├── EmployeesController.cs
│   ├── ProjectsController.cs
│   ├── TeamsController.cs
│   ├── TasksController.cs
│   ├── CommentsController.cs
│   ├── LeavesController.cs
│   ├── InvoicesController.cs
│   └── ProfitsController.cs
├── Models/               # Data models
│   ├── Employee.cs
│   ├── Project.cs
│   ├── Team.cs
│   ├── TaskAssignment.cs
│   ├── Comment.cs
│   ├── Leave.cs
│   ├── Invoice.cs
│   └── Profit.cs
├── Repositories/         # Repository pattern implementation
│   ├── Interfaces/
│   │   ├── IEmployeeRepository.cs
│   │   ├── IProjectRepository.cs
│   │   ├── ITeamRepository.cs
│   │   ├── ITeamMemberRepository.cs
│   │   ├── ITaskAssignmentRepository.cs
│   │   ├── ICommentRepository.cs
│   │   ├── ILeaveRepository.cs
│   │   ├── IInvoiceRepository.cs
│   │   └── IProfitRepository.cs
│   └── Implementations/
│       ├── EmployeeRepository.cs
│       ├── ProjectRepository.cs
│       ├── TeamRepository.cs
│       ├── TeamMemberRepository.cs
│       ├── TaskAssignmentRepository.cs
│       ├── CommentRepository.cs
│       ├── LeaveRepository.cs
│       ├── InvoiceRepository.cs
│       └── ProfitRepository.cs
├── Data/                 # Database connection
│   └── DatabaseHelper.cs
├── Views/               # Razor views
│   ├── Home/
│   ├── Employees/
│   ├── Projects/
│   ├── Teams/
│   ├── Tasks/
│   ├── Comments/
│   ├── Leaves/
│   ├── Invoices/
│   ├── Profits/
│   └── Shared/
├── wwwroot/             # Static files (CSS, JS, images)
├── appsettings.json     # Configuration
└── Program.cs           # Application entry point
```

## 💡 Usage

- ### Dashboard
    - View real-time statistics for all modules
    - Quick access to all management sections
    - Visual cards with counts and metrics

- ### Employee Management
    1. Navigate to **Employees** section
    2. Click **Create New** to add employees
    3. View, edit, or delete employee records
    4. Track employee details, positions, and salaries

- ### Project Management
    1. Go to **Projects** section
    2. Create new projects with:
        - Project name and description
        - Budget and deadline
        - Status tracking
    3. Monitor project progress and completion

- ### Team Management
    1. Access **Teams** section
    2. Create teams and assign members
    3. Manage team composition
    4. Track team assignments

- ### Task Assignment
    1. Navigate to **Tasks** section
    2. Assign tasks to specific teams
    3. Link tasks to projects
    4. Track task completion status

- ### Leave Management
    1. Go to **Leaves** section
    2. Create leave requests with:
        - Employee selection
        - Leave type and dates
        - Approval status
    3. Monitor leave balances

- ### Invoice & Profit Tracking
    1. Access **Invoices** section to create project invoices
    2. View **Profits** to monitor financial performance
    3. Track project budgets vs actual costs

## 🖼️ Screenshots

- ### Dashboard
![Home Screen](Screenshots/HomeScreen.jpeg)
*Main dashboard with real-time statistics and overview of all modules*

- ### Projects Management
![Projects](Screenshots/Projects.jpeg)
*Project listing and management interface*

- ### Team Management
![Teams](Screenshots/Teams.jpeg)
*Team creation and member assignment*

- ### Task Assignments
![Task Assignments](Screenshots/TaskAssignments.jpeg)
*Task assignment and tracking system*

- ### Invoice Management
![Invoices](Screenshots/Invoices.jpeg)
*Invoice creation and management*

- ### Financial Details
![Financial Details](Screenshots/FinancialDetails.jpeg)
*Profit tracking and financial performance metrics*

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👤 Author

This repository is created by [Nuraddin0](https://github.com/Nuraddin0)


## 📧 Support

For issues, questions, or suggestions, please open an issue on the [GitHub repository](https://github.com/Nuraddin0/Project-Management-System/issues).

---
